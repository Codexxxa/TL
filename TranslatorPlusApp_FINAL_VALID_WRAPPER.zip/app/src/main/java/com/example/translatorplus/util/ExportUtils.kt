
package com.example.translatorplus.util

import android.content.Context
import android.os.Environment
import com.example.translatorplus.data.TranslationEntry
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

fun exportToJson(context: Context, originalJson: String, entries: List<TranslationEntry>): File {
    val output = JSONObject(originalJson)
    val translations = entries.associateBy { it.id }

    val events = output.optJSONArray("events") ?: JSONArray()
    for (i in 0 until events.length()) {
        val event = events.optJSONObject(i) ?: continue
        val pages = event.optJSONArray("pages") ?: continue
        for (p in 0 until pages.length()) {
            val page = pages.optJSONObject(p) ?: continue
            val listCmds = page.optJSONArray("list") ?: continue
            for (j in 0 until listCmds.length()) {
                val cmd = listCmds.optJSONObject(j) ?: continue
                val id = "${i}_${p}_$j"
                if (translations.containsKey(id)) {
                    val value = translations[id]?.translated ?: ""
                    cmd.put("parameters", value)
                }
            }
        }
    }

    val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val fileName = "translated_$time.json"
    val file = File(context.getExternalFilesDir(null), fileName)
    FileWriter(file).use { it.write(output.toString(2)) }
    return file
}
