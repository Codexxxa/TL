
package com.example.translatorplus.util

import com.example.translatorplus.data.TranslationEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

object OpenAiTranslator {
    private const val endpoint = "https://api.openai.com/v1/chat/completions"

    suspend fun translateAll(
        apiKey: String,
        entries: List<TranslationEntry>,
        targetLang: String = "English",
        onResult: (Map<String, String>) -> Unit
    ) = withContext(Dispatchers.IO) {
        val client = OkHttpClient()
        val updated = mutableMapOf<String, String>()

        for (entry in entries.filter { it.translated.isEmpty() }) {
            val prompt = "Translate this Japanese sentence to $targetLang:
「${entry.original}」"

            val body = JSONObject()
            body.put("model", "gpt-3.5-turbo")
            body.put("messages", JSONArray().put(JSONObject()
                .put("role", "user")
                .put("content", prompt)))
            body.put("temperature", 0.3)

            val request = Request.Builder()
                .url(endpoint)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(RequestBody.create("application/json".toMediaTypeOrNull(), body.toString()))
                .build()

            try {
                val response = client.newCall(request).execute()
                val json = JSONObject(response.body?.string() ?: "")
                val result = json.getJSONArray("choices")
                    .getJSONObject(0).getJSONObject("message")
                    .getString("content").trim()

                updated[entry.id] = result
            } catch (e: IOException) {
                updated[entry.id] = "[FAILED]"
            }
        }

        onResult(updated)
    }
}
