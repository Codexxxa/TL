
package com.example.translatorplus.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun LanguageSelector(selectedLang: String, onLangChange: (String) -> Unit) {
    val options = listOf("English", "Indonesian", "Spanish", "French", "German", "Chinese", "Korean")
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Column {
            Text(text = "Target Language:")
            Button(onClick = { expanded = true }) {
                Text(selectedLang)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { lang ->
                    DropdownMenuItem(
                        text = { Text(lang) },
                        onClick = {
                            onLangChange(lang)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
