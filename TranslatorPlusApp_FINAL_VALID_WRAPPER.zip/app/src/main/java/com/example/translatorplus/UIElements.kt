
package com.example.translatorplus.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.translatorplus.data.TranslationEntry

@Composable
fun FilterRow(viewModel: TranslationViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(onClick = { viewModel.setFilter(TranslationFilter.ALL) }) { Text("Semua") }
        Button(onClick = { viewModel.setFilter(TranslationFilter.UNTRANSLATED) }) { Text("Belum Diterjemahkan") }
        Button(onClick = { viewModel.setFilter(TranslationFilter.TRANSLATED) }) { Text("Sudah Diterjemahkan") }
    }
}

@Composable
fun ThemeSettingsPanel(viewModel: SettingsViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(onClick = { viewModel.toggleTheme() }) {
            Text(if (viewModel.state.isDarkTheme) "Mode Terang" else "Mode Gelap")
        }
        Button(onClick = { viewModel.increaseFont() }) { Text("A+") }
        Button(onClick = { viewModel.decreaseFont() }) { Text("A-") }
    }
}

@Composable
fun TranslationEditorWithFont(viewModel: TranslationViewModel, fontSize: Float) {
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        viewModel.entries.forEach { entry ->
            Text("Original: ${entry.original}", fontSize = fontSize.sp)
            TextField(
                value = entry.translated,
                onValueChange = { newText -> viewModel.updateEntry(entry.id, newText) },
                label = { Text("Terjemahan") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun ExportButton(entries: List<TranslationEntry>, originalJson: String) {
    Button(onClick = {
        // Dummy action
    }, modifier = Modifier.padding(4.dp)) {
        Text("Ekspor JSON")
    }
}

@Composable
fun AutoTranslateButton(viewModel: TranslationViewModel, apiKey: String) {
    Button(onClick = {
        // Dummy action
    }, modifier = Modifier.padding(4.dp)) {
        Text("Auto Translate")
    }
}

@Composable
fun BackupButton(json: String, entries: List<TranslationEntry>) {
    Button(onClick = {
        // Dummy action
    }, modifier = Modifier.padding(4.dp)) {
        Text("Backup Proyek")
    }
}
