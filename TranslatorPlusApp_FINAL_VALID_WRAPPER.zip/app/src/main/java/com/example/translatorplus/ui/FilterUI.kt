
package com.example.translatorplus.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.translatorplus.viewmodel.TranslationViewModel
import com.example.translatorplus.viewmodel.TranslationFilter

@Composable
fun FilterRow(viewModel: TranslationViewModel) {
    Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(onClick = { viewModel.setFilter(TranslationFilter.ALL) }) {
            Text("Semua")
        }
        Button(onClick = { viewModel.setFilter(TranslationFilter.UNTRANSLATED) }) {
            Text("Belum")
        }
        Button(onClick = { viewModel.setFilter(TranslationFilter.TRANSLATED) }) {
            Text("Sudah")
        }
    }
}
