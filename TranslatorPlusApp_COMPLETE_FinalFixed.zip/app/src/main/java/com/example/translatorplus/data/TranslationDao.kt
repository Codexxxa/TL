
package com.example.translatorplus.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TranslationDao {
    @Query("SELECT * FROM translations")
    fun getAll(): Flow<List<TranslationEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<TranslationEntry>)

    @Update
    suspend fun update(entry: TranslationEntry)

    @Query("DELETE FROM translations")
    suspend fun clear()
}
