
package com.example.translatorplus.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.translatorplus.viewmodel.TranslationViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun TranslationEditor(viewModel: TranslationViewModel) {
    val entries by viewModel.entries.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(8.dp).verticalScroll(rememberScrollState())) {
        entries.forEach { entry ->
            Text(text = "Original:", fontSize = 12.sp)
            Text(text = entry.original, fontSize = 14.sp, modifier = Modifier.padding(bottom = 4.dp))
            Text(text = "Translation:", fontSize = 12.sp)
            var translated by remember { mutableStateOf(entry.translated) }
            TextField(
                value = translated,
                onValueChange = {
                    translated = it
                    viewModel.updateTranslation(entry.id, translated)
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                singleLine = false
            )
        }
    }
}
