
package com.example.translatorplus.util

import android.content.Context
import com.example.translatorplus.data.TranslationEntry
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

fun createBackupZip(context: Context, originalJson: String, entries: List<TranslationEntry>): File {
    val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val zipFile = File(context.getExternalFilesDir(null), "backup_$time.zip")

    val csv = StringBuilder()
    csv.append("id,original,translated\n")
    entries.forEach {
        csv.append("${it.id},"${it.original}","${it.translated}"\n")
    }

    ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
        val jsonBytes = originalJson.toByteArray()
        val csvBytes = csv.toString().toByteArray()

        zos.putNextEntry(ZipEntry("original.json"))
        zos.write(jsonBytes)
        zos.closeEntry()

        zos.putNextEntry(ZipEntry("translations.csv"))
        zos.write(csvBytes)
        zos.closeEntry()
    }

    return zipFile
}

fun extractBackupZip(context: Context, zipUri: InputStream): Pair<String, List<TranslationEntry>> {
    var json = ""
    val entries = mutableListOf<TranslationEntry>()

    ZipInputStream(BufferedInputStream(zipUri)).use { zis ->
        var ze: ZipEntry?
        val buffer = ByteArray(1024)
        while (zis.nextEntry.also { ze = it } != null) {
            val name = ze!!.name
            val bos = ByteArrayOutputStream()
            var count: Int
            while (zis.read(buffer).also { count = it } != -1) {
                bos.write(buffer, 0, count)
            }

            when (name) {
                "original.json" -> json = bos.toString()
                "translations.csv" -> {
                    val lines = bos.toString().split("\n")
                    for (line in lines.drop(1)) {
                        val parts = line.split(",").map { it.trim('"') }
                        if (parts.size >= 3) {
                            entries.add(TranslationEntry(parts[0], parts[1], parts[2]))
                        }
                    }
                }
            }
            zis.closeEntry()
        }
    }

    return json to entries
}
