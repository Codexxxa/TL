
package com.example.translatorplus.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translations")
data class TranslationEntry(
    @PrimaryKey val id: String,
    val original: String,
    val translated: String
)
