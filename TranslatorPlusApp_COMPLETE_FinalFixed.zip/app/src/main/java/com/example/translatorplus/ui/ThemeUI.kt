
package com.example.translatorplus.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ThemeSettingsPanel(fontSize: Float, onFontSizeChange: (Float) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(onClick = { onFontSizeChange(fontSize + 2) }) {
            Text("A+")
        }
        Button(onClick = { onFontSizeChange(fontSize - 2) }) {
            Text("A-")
        }
    }
}
