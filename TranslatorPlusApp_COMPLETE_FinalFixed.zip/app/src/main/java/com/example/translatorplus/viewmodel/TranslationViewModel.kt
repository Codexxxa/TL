
package com.example.translatorplus.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.translatorplus.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class TranslationViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TranslationDatabase.getDatabase(application)
    private val dao = db.translationDao()

    private val _entries = MutableStateFlow<List<TranslationEntry>>(emptyList())
    val entries: StateFlow<List<TranslationEntry>> = _entries.asStateFlow()

    var originalJson: String = ""

    init {
        viewModelScope.launch {
            dao.getAll().collect {
                _entries.value = it
            }
        }
    }

    fun parseAndLoad(json: String) {
        originalJson = json
        val parsed = parseRpgMakerJson(json)
        viewModelScope.launch {
            dao.clear()
            dao.insertAll(parsed)
        }
    }

    fun updateTranslation(id: String, translated: String) {
        viewModelScope.launch {
            val entry = _entries.value.find { it.id == id } ?: return@launch
            dao.update(entry.copy(translated = translated))
        }
    }

    private fun parseRpgMakerJson(json: String): List<TranslationEntry> {
        val list = mutableListOf<TranslationEntry>()
        val obj = JSONObject(json)
        val events = obj.optJSONArray("events") ?: JSONArray()
        for (i in 0 until events.length()) {
            val event = events.optJSONObject(i) ?: continue
            val pages = event.optJSONArray("pages") ?: continue
            for (p in 0 until pages.length()) {
                val page = pages.optJSONObject(p) ?: continue
                val listCmds = page.optJSONArray("list") ?: continue
                for (j in 0 until listCmds.length()) {
                    val cmd = listCmds.optJSONObject(j) ?: continue
                    if (cmd.optInt("code") == 401 || cmd.optInt("code") == 405) {
                        val text = cmd.optString("parameters")
                        val id = "${i}_${p}_$j"
                        list.add(TranslationEntry(id, text, ""))
                    }
                }
            }
        }
        return list
    }
}
