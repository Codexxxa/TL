
package com.example.translatorplus.ui

import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.compose.ui.unit.sp

data class SettingsState(
    val fontSize: Float = 16f,
    val isDarkTheme: Boolean = true
)

class SettingsViewModel : ViewModel() {
    var state by mutableStateOf(SettingsState())
        private set

    fun toggleTheme() {
        state = state.copy(isDarkTheme = !state.isDarkTheme)
    }

    fun increaseFont() {
        state = state.copy(fontSize = state.fontSize + 2)
    }

    fun decreaseFont() {
        state = state.copy(fontSize = maxOf(12f, state.fontSize - 2))
    }
}
