
package com.example.translatorplus.data

data class TranslationEntry(
    val id: String,
    val original: String,
    val translated: String
)
