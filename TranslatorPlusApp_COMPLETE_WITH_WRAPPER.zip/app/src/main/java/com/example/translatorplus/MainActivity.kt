
package com.example.translatorplus

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.translatorplus.ui.*
import com.example.translatorplus.util.*
import com.example.translatorplus.viewmodel.TranslationViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: TranslationViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val scope = rememberCoroutineScope()
                var fontSize by remember { mutableStateOf(16f) }
                var apiKey by remember { mutableStateOf("YOUR_API_KEY_HERE") }
                var targetLang by remember { mutableStateOf("English") }

                Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    ThemeSettingsPanel(fontSize) { fontSize = it }
                    FilterRow(viewModel)
                    LanguageSelector(selectedLang = targetLang, onLangChange = { targetLang = it })
                    TranslationEditor(viewModel = viewModel)

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Button(onClick = {
                            val file = exportToJson(this@MainActivity, viewModel.originalJson, viewModel.entries.value)
                            println("Exported to ${file.absolutePath}")
                        }) {
                            Text("Ekspor JSON")
                        }
                        Button(onClick = {
                            val file = createBackupZip(this@MainActivity, viewModel.originalJson, viewModel.entries.value)
                            println("Backup created: ${file.absolutePath}")
                        }) {
                            Text("Backup ZIP")
                        }
                        Button(onClick = {
                            scope.launch {
                                OpenAiTranslator.translateAll(apiKey, viewModel.entries.value, targetLang) { result ->
                                    result.forEach { (id, translation) ->
                                        viewModel.updateTranslation(id, translation)
                                    }
                                }
                            }
                        }) {
                            Text("Auto Translate")
                        }
                    }
                }
            }
        }
    }
}
