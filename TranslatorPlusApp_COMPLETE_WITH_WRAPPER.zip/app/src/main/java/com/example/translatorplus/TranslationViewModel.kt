
package com.example.translatorplus.ui

import android.app.Application
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.translatorplus.data.TranslationEntry
import kotlinx.coroutines.launch

enum class TranslationFilter {
    ALL, UNTRANSLATED, TRANSLATED
}

class TranslationViewModel(application: Application) : AndroidViewModel(application) {
    var entries = mutableStateListOf<TranslationEntry>()
        private set

    var originalJson: String by mutableStateOf("")
    var filter: TranslationFilter by mutableStateOf(TranslationFilter.ALL)

    fun loadFromJson(json: String) {
        originalJson = json
        val parsed = parseRpgMakerJson(json)
        entries.clear()
        entries.addAll(parsed)
    }

    fun updateEntry(id: String, translation: String) {
        entries.indexOfFirst { it.id == id }.takeIf { it >= 0 }?.let { index ->
            entries[index] = entries[index].copy(translated = translation)
        }
    }

    fun setFilter(f: TranslationFilter) {
        filter = f
        // Filtering logic can be applied here if needed
    }
}

// Dummy parser
fun parseRpgMakerJson(json: String): List<TranslationEntry> {
    return listOf(
        TranslationEntry("1", "こんにちは", ""),
        TranslationEntry("2", "さようなら", "")
    )
}
