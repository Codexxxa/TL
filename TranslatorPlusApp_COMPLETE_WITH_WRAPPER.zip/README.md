# TranslatorPlusApp

Aplikasi penerjemah RPG Maker untuk Android, dibuat dengan Jetpack Compose, Room, dan OpenAI GPT.

## Build Instructions
1. Open this project in Android Studio
2. Sync Gradle
3. Use `Build > Build APK` to generate APK
